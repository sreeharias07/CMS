package com.example.canteenmanagement;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class student_qr_dash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_qr_dash);
    }
}
